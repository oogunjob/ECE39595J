public class LaysEggsNotBroody implements LaysEggs{
    public void laysEggs() {
        System.out.println("Lays eggs and will give them up if fed.");
    }
}
