public class DoesNotLayEggs implements LaysEggs {
    public void laysEggs() {
        System.out.println("Not an egg layer.");   
    }
}
