public interface LaysEggs {
    public abstract void laysEggs( );
}
