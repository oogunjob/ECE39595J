public class LaysEggsBroody implements LaysEggs{
    public void laysEggs() {
        System.out.println("Lays eggs, but will fight you for them.");
    }
}
