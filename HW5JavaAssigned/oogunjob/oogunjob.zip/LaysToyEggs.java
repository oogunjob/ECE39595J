public class LaysToyEggs implements LaysEggs{
    public void laysEggs() {
        System.out.println("Lays toy eggs.");
    }
}